<?php

?>
<html>
	<head>
		<title>Service-Now Soap Client PHP Examples</title>
	</head>
	
	<body>
		<div style="text-align: center;">
			<h2>Service-Now Soap Client PHP Examples</h2>
			<div><a href="pull_record.php">pull_record.php</a> - Pulling a record from based on sys_id</div>
		</div>
	</body>
</html>