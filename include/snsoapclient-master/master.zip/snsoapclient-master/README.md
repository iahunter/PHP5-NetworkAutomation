snsoapclient
============

Various Soap libraries for servicenow.

1. examples - Various soap examples for servicenow interaction. php and python currently.  

2. phpsoapclient - Generic php interface, ServicenowSoapClient for extending
to create php classes for interaction with servicenow.

3. snpydump - Python library to dump servicenow data into an external mysql database.   

4. License - This project falls under the WTFPL (http://www.wtfpl.net/) license.  See license.txt for full agreement or reference above link for additional information.  


